<?php
include 'functions.php';

$products = [
    1 => ['name' => 'T-Shirt', 'price' => 350],
    2 => ['name' => 'Jeans', 'price' => 800],
    3 => ['name' => 'Sneakers', 'price' => 1200],
];

if (isset($_POST['add'])) {
    $id = $_POST['id'];
    $product = $products[$id];
    addToCart($id, $product['name'], $product['price']);
    header("Location: cart.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
<meta charset="UTF-8">
<title>商品列表</title>
<style>
body { font-family: "微軟正黑體"; margin: 40px; }
table { border-collapse: collapse; width: 50%; }
td, th { padding: 10px; border: 1px solid #aaa; text-align: center; }
button { padding: 5px 10px; }
</style>
</head>
<body>
<h2>🛒 商品列表</h2>
<table>
<tr><th>商品名稱</th><th>價格</th><th>操作</th></tr>
<?php foreach ($products as $id => $p): ?>
<tr>
<td><?= htmlspecialchars($p['name']) ?></td>
<td>$<?= $p['price'] ?></td>
<td>
<form method="post">
    <input type="hidden" name="id" value="<?= $id ?>">
    <button name="add">加入購物車</button>
</form>
</td>
</tr>
<?php endforeach; ?>
</table>
<p><a href="cart.php">查看購物車</a></p>
<?php
    if (!isset($_SESSION["username"])){
?>
        <p><a href="login.php">登入</a></p>
        <p><a href="register.html">註冊</a></p>
<?php     
}else{   
    ?>
        <p><a href="logout.php">登出</a></p>
        
<?php
    }
?>
</body>
</html>