<!DOCTYPE html>
<html>
<head><title>會員登入</title></head>
<body>
<?php
session_start();
// 檢查是否是表單送回
if (isset($_SESSION["database1"])){
    $db_name=$_SESSION["database1"];
    $db_username=$_SESSION["database2"];
    $db_password=$_SESSION["database3"];

}
if (isset($_POST["login"])){

    $acc=$_POST["name"];
    $pwd=$_POST["pwd"];
    if ( ( strcmp($acc , $db_username) == 0 ) and
        ( strcmp($pwd , $db_password) == 0 )){           
            $_SESSION["name"]=$db_name;
            $_SESSION["username"]=$db_username;
            $_SESSION["password"]=$db_password;  
            header("Location:index.php");
    }
   else  print "帳密錯誤，請重新輸入!<br/>";
}
?>
<form action="login.php" method="post">
使用者姓名: <input type="text" name="name" size ="10"/><br/>
密碼: <input type="password" name="pwd" size="30"/><br/>
<br/><br/>
<input type="submit" name="login" value="登入"/>
</form>
</body>
</html>
